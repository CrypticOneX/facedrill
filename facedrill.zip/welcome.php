<!DOCTYPE HTML>
<html lang='en'>
     <head>
         <meta charset='UTF-8'/>
         <title>Face Drill</title>
         <meta name='viewport' content='width=device-width'/>
         <link rel='stylsheet' href='http://facedrill.ml/cloth.css'/>
     </head>
     <body>
         <div class='custom'>
             <h1><img src='facedrill.png' align='center' alt='facedrill'/></h1>
             <hr>
             <h1>Welcome User You have Successfully Signup With Face Drill</h1>
             <h2>Click on below link to login in</h2>
             <div align='center'>
                 <a href='http://facedrill.ml/index.php'>Login</a>
             </div><br><br><br>
             <hr>
             <p>Copyright 2017 | FaceDrill</p>
             <p>Developed by <a href='http://facebook.com/ashut0shsingh'>Ashutosh Singh</a></p>
             <a href='http://facedrill.ml/about.php'>About</a>
         </div>
     </body>
</html>