<?php
    error_reporting(0);
    $conn=mysqli_connect('mysql.hostinger.in','u260844331_ashut','jz6PGtysbhKuxZbQ');
    $note=mysqli_select_db($conn,'u260844331_knigh');
    if(!$note) {
    	 die("Error in Establishing Database Connection!");
    }
?>