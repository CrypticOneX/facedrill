<?php
    error_reporting(0);
    header("location: http://facedrill.ga/index.php");
?>