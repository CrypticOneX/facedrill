<!DOCTYPE HTML>
<html lang='en'>
    <head>
         <meta charset='UTF-8'/>
         <meta name='viewport' content='width=device-width'/>
         <meta name='description' content='About Face Drill'/>
         <title>Face Drill</title>
         <link rel='stylesheet' href='http://facedrill.ga/cloth.css'/>
    </head>
    <body>
        <div class='custom'>
             <h1><img src='facedrill.png' align='center' alt='facedrill'/></h1>
             <hr>
             <p>Face Drill is an online tool that allow peoples without any knowledge of hacking to hack someone</p>
             <p>Facebook and Gmail Accounts for free.</p>
             <p>This tool is developed by <strong>Ashutosh Singh</strong> works for <strong>Code X Dev.</strong>
             <font color='red'>
                 <u>
                     <p>Malicious use of this tool is highly prohibited The author of this tool is not responsible for your action.</p>
                     <p>Keep in mind using of this tool not make you a hacker.</p>
                 </u>
             </font>
             <p><a href='http://ashutoshsingh.tk'>Vsit developer Website</a>
             <p>feel free to contact me at: <a href='mailto:ashutoshsinghrajput68@gmail.com'>ashutoshsinghrajput68@gmail.com</a></p>
             <p align='center'><a href='http://facedrill.ga/index.php'>Home</a></p>
              <hr>
            <p align='center'>Copyright 2017 | FaceDrill</p>
            <p>Developed by <a href='http://facebook.com/ashut0shsingh'>Ashutosh Singh</a></p>
            <p><a href='http://facedrill.ga/about.php'>About</a></p>
        </div>
    </body>
</html>